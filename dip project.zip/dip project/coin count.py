import cv2
import numpy as np

# Read the input image
image = cv2.imread('c10.jpg')

# Convert the image to grayscale
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Apply Gaussian blur to reduce noise and improve circle detection
blurred = cv2.GaussianBlur(gray, (9, 9), 2)

# Use Hough Circle Transform to detect circles (coins) in the blurred grayscale image
circles = cv2.HoughCircles(
    blurred,
    cv2.HOUGH_GRADIENT,
    dp=1,
    minDist=20,
    param1=50,
    param2=30,
    minRadius=10,
    maxRadius=30
)

# Initialize a counter for the number of coins
num_coins = 0

# If circles were detected, iterate through them
if circles is not None:
    circles = np.uint16(np.around(circles))
    num_coins = len(circles[0])

    # Draw the detected circles (coins) on the original image
    for i in circles[0, :]:
        center = (i[0], i[1])  # Circle center (x, y)
        radius = i[2]  # Circle radius
        
        # Calculate the diameter of the coin
        diameter = 2 * radius
        
        # Draw the outer circle
        cv2.circle(image, center, radius, (0, 255, 0), 2)
        # Draw the center of the circle
        cv2.circle(image, center, 3, (0, 0, 255), -1)
        
        # Print the diameter of the coin
        print(f"Coin detected at center: {center} with diameter: {diameter} ")

# Print the number of coins detected
print("Number of coins detected:", num_coins)

# Display the result
cv2.imshow("Detected Coins in the image", image)
cv2.waitKey(0)
cv2.destroyAllWindows()
